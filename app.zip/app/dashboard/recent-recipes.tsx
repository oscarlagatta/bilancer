


export default function RecentRecipes() {

   return <div>Recent Recipes</div>

}