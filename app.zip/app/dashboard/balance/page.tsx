export default function BalancePage() {
  return <div>Bilanci</div>;
}
