export default function NewCategoryPage() {
    return <div> New Category Page</div>
}