export default function BalancePage() {
  return <div>Settings</div>;
}
