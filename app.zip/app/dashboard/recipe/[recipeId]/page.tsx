export default function RecipePage() {
    return (
        <div>
            Recipe Page
        </div>
    )
}