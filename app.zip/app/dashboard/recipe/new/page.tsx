export default function NewRecipePage() {
    return <div>New Recipe Page</div>
}