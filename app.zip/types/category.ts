export type CategoryIngredient = {
  id: number;
  name: string;
};
