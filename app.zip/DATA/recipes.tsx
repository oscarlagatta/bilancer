export const recipesDB = [{}];
